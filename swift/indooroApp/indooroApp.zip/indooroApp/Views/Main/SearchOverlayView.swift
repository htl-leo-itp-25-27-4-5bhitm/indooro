import SwiftUI

struct SearchOverlayView: View {
    @Binding var searchText: String
    let searchResults: [Product]
    let isSearching: Bool
    let onClearSearch: () -> Void
    let onSelectProduct: (Product) -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            // Suchleiste
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                
                TextField("Produkt suchen...", text: $searchText)
                    .textFieldStyle(PlainTextFieldStyle())
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                        onClearSearch()
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
            .padding(.horizontal)
            .padding(.top, 60)
            
            // Suchergebnisse
            if !searchResults.isEmpty {
                VStack(spacing: 0) {
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(searchResults) { product in
                                ProductSearchRow(product: product) {
                                    onSelectProduct(product)
                                }
                                
                                Divider()
                            }
                        }
                    }
                    .frame(maxHeight: 400)
                }
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding(.horizontal)
                .padding(.top, 5)
                .transition(.move(edge: .top).combined(with: .opacity))
            } else if isSearching {
                ProgressView()
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                    .padding(.horizontal)
                    .padding(.top, 5)
            }
            
            Spacer()
        }
    }
}
