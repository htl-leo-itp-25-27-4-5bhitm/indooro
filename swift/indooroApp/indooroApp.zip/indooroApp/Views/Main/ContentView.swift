import SwiftUI

struct ContentView: View {
    @StateObject var beaconManager = BeaconManager()
    
    // --- SUCHE STATES ---
    @State private var searchText = ""
    @State private var targetProduct: Product? = nil // Das aktuell gesuchte Produkt
    
    // Maßstab: 25 Pixel pro Meter
    let pixelsPerMeter: Double = 25.0
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                
                // === HAUPT-LAYOUT (Karte & Header) ===
                VStack(spacing: 0) {
                    
                    // 1. KOPFZEILE
                    HeaderView(
                        userPosition: beaconManager.userPosition,
                        targetProduct: targetProduct,
                        onClearTarget: { targetProduct = nil }
                    )
                    
                    // 2. SCROLLBARE KARTE
                    MapView(
                        beaconManager: beaconManager,
                        pixelsPerMeter: pixelsPerMeter,
                        targetProduct: targetProduct
                    )
                }
                .blur(radius: beaconManager.searchResults.isEmpty ? 0 : 3) // Weichzeichnen wenn Suche aktiv
                
                // === SUCHE OVERLAY ===
                SearchOverlayView(
                    searchText: $searchText,
                    searchResults: beaconManager.searchResults,
                    isSearching: beaconManager.isSearching,
                    onClearSearch: {
                        beaconManager.clearSearch()
                    },
                    onSelectProduct: { product in
                        withAnimation {
                            targetProduct = product
                            searchText = ""
                            beaconManager.clearSearch()
                        }
                    }
                )
                .onChange(of: searchText) { newValue in
                    if newValue.count > 2 {
                        beaconManager.searchProducts(query: newValue)
                    } else {
                        beaconManager.clearSearch()
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

// Preview für Canvas
#Preview {
    ContentView()
}
